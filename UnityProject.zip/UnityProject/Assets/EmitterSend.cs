using UnityEngine;
using System.Collections;

public class EmitterSend : MonoBehaviour {

	// Use this for initialization
	void Start () {
	EMarray = GameObject.FindGameObjectsWithTag("NIemitter");
	SendEmit();
	}
	
	// Update is called once per frame
	void Update () {
	
	
	}

	public GameObject[] EMarray;
	
	void SendEmit(){
		
	
		
		int x = Random.Range(0, EMarray.Length);
		int y = Random.Range(0, 8);
		int z = Random.Range(0, 3);
		
		Emitter emi; 
		emi = EMarray[x].GetComponent<Emitter>();
		
	
		Debug.Log (y);
		//Debug.Log ("y");
		for (int i = 0; i < y; i++)
		{
		//Debug.Log ("sending message");
		emi.BubbleUp(y,z);
		}
	}
}
