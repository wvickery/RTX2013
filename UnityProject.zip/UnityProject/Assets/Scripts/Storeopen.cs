using UnityEngine;
using System.Collections;

public class Storeopen : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	
	void OnMouseOver() {
	 
	}
	
	public int rootinvt;
	public GameObject rp;
	public Texture image;
	public string text;
	public Texture buyrootsicon;
	public Texture rainicon;
	public Texture pickicon;
	public Texture niicon;
	public Texture picon;
	public Texture coicon;
	public Texture supergrowicon;
	public Texture soilfixicon;
	public Texture nigenicon;
	public Texture sheildicon;
	public Texture rejuvinateicon;
	public Texture nisponge;
	
    public Rect windowRect0 = new Rect(496, 125, 38, 141);
	//public Rect windowRect0 = new Rect(50, 50, 50, 50);
	public Rect windowRect1 = new Rect(-180, -50, 50, 50);
    void OnGUI() {
        GUI.color = Color.red;
		windowRect0 = GUI.Window(0, windowRect0, StoreOpenWindow, "redWindow");  
        GUI.color = Color.green;
	    windowRect1 = GUI.Window(1, windowRect1, StoreCloseWindow, "Green Window");
		//windowRect1.Set(-180,-56,50,50);
	//	Debug.Log ("SPacer");
		 // if (windowRect0.Contains(Input.mousePosition))
           // print("Inside");
    		//WindowSlide();
		}
    
	void StoreOpenWindow(int windowID) {
        if (GUI.Button(new Rect(05, 30, 30, 80), "$"))
             //GUI.color = Color.green;
	   		// windowRect1 = GUI.Window(1, windowRect1, DoMyWindow, "Green Window");
			 WindowSlide ();
        
        GUI.DragWindow(new Rect(0, 0, 10000, 10000));
    }
	
	void StoreCloseWindow(int windowID){
		if (GUI.Button(new Rect(10, 30, 80, 80), new GUIContent (text, nisponge)))
		CloseWindow ();
		if (GUI.Button(new Rect(250, 30, 80, 80), new GUIContent (text, rainicon)))
		RainPower ();
		if (GUI.Button(new Rect(500, 30, 80, 80), new GUIContent (text, pickicon)))
		CloseWindow ();
		if (GUI.Button(new Rect(10, 250, 80, 80), new GUIContent (text, supergrowicon)))
		CloseWindow ();
		if (GUI.Button(new Rect(250, 250, 80, 80), new GUIContent (text, buyrootsicon)))
		BuyRoots ();
		if (GUI.Button(new Rect(500, 250, 80, 80), new GUIContent (text, sheildicon)))
		CloseWindow ();
		if (GUI.Button(new Rect(10, 500, 80, 80), new GUIContent (text, soilfixicon)))
		CloseWindow ();
	    if (GUI.Button(new Rect(250, 500, 80, 80), new GUIContent (text, nigenicon)))
		CloseWindow ();
		if (GUI.Button(new Rect(500, 500, 80, 80), new GUIContent (text, rejuvinateicon)))
		CloseWindow ();
		
		
	}
	
	void WindowSlide(){
	windowRect1.Set(88,11,600,600);
	windowRect0.Set (1380, 125, 80, 141);
	Debug.Log("Potato");
	}
	
	void CloseWindow(){
	windowRect1.Set (-180, -50, 50, 50);
	windowRect0.Set (811, 20, 38, 141);
	}
	void RainPower(){
	Debug.Log ("rainpower");
	windowRect1.Set (-180, -50, 50, 50);
	windowRect0.Set (811, 20, 38, 141);
	//GUI.Label(Rect(Input.mousePosition.x, Screen.height - Input.mousePosition.y-12, 32, 32), rainicon); 
	Instantiate(rp);
	}

	void BuyRoots(){
	rootinvt = rootinvt + 3;	
	Debug.Log (rootinvt);
	windowRect1.Set (-180, -50, 50, 50);
	windowRect0.Set (811, 20, 38, 141);
	}







}

