using UnityEngine;
using System.Collections;

public class Emitter : MonoBehaviour {

	public Rigidbody nibubble;
	
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	public void BubbleUp(int timestoshoot, int firerate){
	
		for (int r = 0; r < timestoshoot; r++)
		{
			Debug.Log (timestoshoot);
			
			Rigidbody clone;
            clone = Instantiate(nibubble) as Rigidbody;
			//clone = Instantiate(nibubble, transform.position, transform.rotation) as Rigidbody;
            //clone.velocity = transform.TransformDirection(Vector3.up * 10);
									
			
		}
		
	}


}
