using UnityEngine;
using System.Collections;

public class Root : MonoBehaviour
{
	OTSprite sprite;

	public Texture rootTextureLiveBase;
	public Texture rootTextureLiveSection;
	public Texture rootTextureLiveTip; 
	
	public Texture rootTextureLockedBase;
	public Texture rootTextureLockedSection;
	public Texture rootTextureLockedTip;
	
	private string rootType;
	private string rootState;
	
	void Start ()
	{
		sprite = GetComponent<OTSprite>();
		
		initialize();
		
		sprite.onMouseEnterOT = onMouseEnter;
		sprite.onMouseExitOT = onMouseExit;
		sprite.onInput = onInput;
	}
/////////////////////////////////////////////////////////////////////////////////////////////	
	
	public void initialize()
	{
		rootType = Constants.rootTypeSection;
		rootState = Constants.rootStateDead;
		
		setImageFromTypeState(rootType,rootState);
	}
	
/////////////////////////////////////////////////////////////////////////////////////////////	
	
	public void onMouseEnter(OTObject owner)
	{
		//TODO need to make sure that we have the green texture
		if(rootState == Constants.rootStateDead)
		{
			sprite.alpha = .5f;	
		}
	}
	
	public void onMouseExit(OTObject owner)
	{
		//TODO need to make sure that we have the green texture
		if(rootState == Constants.rootStateDead)
		{
			sprite.alpha = 0f;	
		}
	}
	
	public void onInput(OTObject owner)
	{
		if(Input.GetMouseButtonDown(0))
        {
			if(rootState == Constants.rootStateDead)
			{
				setRootTypeAndState(Constants.rootTypeSection, Constants.rootStateLive);
			}
        }
	}
	
/////////////////////////////////////////////////////////////////////////////////////////////	
		
	void setPosition(float x, float y)
	{
		sprite.position = new Vector2(x,y);
	}
	
	void setSize(float x, float y)
	{
		sprite.size	= new Vector2(x,y);
	}
	
	string getRootType()
	{
		return rootType;
	}
	
	string getRootState()
	{
		return rootState; 
	}
	
	void setRootType(string newType)
	{
		Texture spriteImage = getImageFromTypeState(newType, rootState);
		
		rootType = newType;
		sprite.image = spriteImage;
	}
	
	void setRootState(string newState)
	{
		Texture spriteImage = getImageFromTypeState(rootType, newState);
		
		rootState = newState;
		sprite.image = spriteImage;
	}
	
	void setRootTypeAndState(string type, string state)
	{
		rootType = type;
		rootState = state;
		
		setImageFromTypeState(type,state);
	}	
	
	void setImageFromTypeState(string type, string state)
	{
		Texture image = getImageFromTypeState(type,state);
		
		if(image == null)
		{
			sprite.alpha = 0f;
			Debug.Log("set alpha to 0");
		}
		else
		{
			sprite.image = image;
			sprite.alpha = 1f;
			
		}
	}
	
	Texture getImageFromTypeState(string type, string state)
	{
		Texture image = null;
		if(state == Constants.rootStateLive)
		{
			if(type == Constants.rootTypeBase)
			{
				image = rootTextureLiveBase;
			}
			else if(type == Constants.rootTypeSection)
			{
				image = rootTextureLiveSection;
			}
			else if(type == Constants.rootTypeTip)
			{
				image = rootTextureLiveTip;
			}
		}
		
		else if(state == Constants.rootStateLocked)
		{
			if(type == Constants.rootTypeBase)
			{
				image = rootTextureLiveBase;
			}
			else if(type == Constants.rootTypeSection)
			{
				image = rootTextureLiveSection;
			}
			else if(type == Constants.rootTypeTip)
			{
				image = rootTextureLiveTip;
			}
		}
		else
		{
			image = null;
		}		
		
		return image;
	}		
}

