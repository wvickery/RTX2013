using UnityEngine;
using System.Collections;

public class RootTriad : MonoBehaviour
{	
	private Root top;
	private Root left;
	private Root right;
		
	// Use this for initialization
	void Start ()
	{
		top = null;
	}
	
	// Update is called once per frame
	void Update ()
	{
	
	}
	

}

