using UnityEngine;
using System.Collections;

public class GameController : MonoBehaviour {
	
	private string stateSeason;
	
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
