using UnityEngine;
using System.Collections;

public class RootGridController : MonoBehaviour
{
	public OTSprite root;
	
	private GameObject[][] rootGrid;
	
	// Use this for initialization
	void Start ()
	{
		
		//loop through all triads
		initiateGrid();
	}
	
	// Update is called once per frame
	void Update ()
	{
	
	}
	
	void initiateGrid()
	{
		rootGrid = new GameObject[Constants.rootGridRows][];
		for (int row=0; row < Constants.rootGridRows; row++)
		{
       		rootGrid[row] = new GameObject[Constants.rootGridCols];
       		for (int col=0; col<Constants.rootGridCols; col++)
			{
				Vector2 position = getTriadPosition(row,col);
				GameObject triad = createTriad("Triad"+row+"_"+col, position);
         		rootGrid[row][col] = triad; 
       		}
    	}
	}
	
	GameObject createTriad(string name, Vector2 position)
	{
		GameObject triad = new GameObject(name);	
		
		triad.transform.position = position;
		
		addTriadRoots(triad);
		
		return triad;
	}
	
	Vector2 getTriadPosition(int row, int col)
	{
		Vector2 position = new Vector2(Constants.triadBasePositionX + (row%2 * Constants.triadXDelta/2), Constants.triadBasePositionY );
		
		float offsetX = col * Constants.triadXDelta;
		float offsetY = row * Constants.triadYDelta;
		
		position.x += offsetX;
		position.y -= offsetY;
		
		return position;
	}
	
	void addTriadRoots(GameObject triadParent)
	{		
		string[]  rootNames = new string[3] {Constants.rootLeft, Constants.rootTop, Constants.rootRight};
		Vector2[] rootPositions = new Vector2[3] {new Vector2(3.4f, 1.8f), new Vector2(-4.2f,4.3f), new Vector2(22.1f,5.5f)};
		Vector2[] rootSizes = new Vector2[3] {new Vector2(27f, 6.75f), new Vector2(28f, 6.75f), new Vector2(28f, 6.75f)};
		float[]   rootRotations = new float[3] {240f, 0f, 300f};
		
		for( int rootIndex = 0; rootIndex <3; rootIndex++)
		{
			OTSprite r = (Instantiate(root.gameObject) as GameObject).GetComponent<OTSprite>();
			
			r.transform.parent = triadParent.transform;

			r.name = triadParent.name + rootNames[rootIndex];
			r.position = rootPositions[rootIndex];
			r.size = rootSizes[rootIndex];
			r.rotation = rootRotations[rootIndex];
			
			
		}
	}
}

