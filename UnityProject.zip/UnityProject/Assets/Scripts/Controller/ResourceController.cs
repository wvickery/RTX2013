using UnityEngine;
using System.Collections;

public class ResourceController: MonoBehaviour {


	private int[] resources;
	
	public int initialCOtwo;
	public int initialNtwo;
	public int initialP;
	
	void Start()
	{
		resources[Constants.indexCOtwo] = initialCOtwo;
		resources[Constants.indexNtwo]  = initialNtwo;
		resources[Constants.indexP]     = initialP;		
	}
	
	int getResourceAmount(int resourceIndex)
	{
		return resources[resourceIndex];
	}
	
	void addResourceAmount(int resourceIndex, int amount)
	{
		resources[resourceIndex] += amount;
	}
	
	void removeResourceAmount(int resourceIndex, int amount)
	{
		resources[resourceIndex] -= amount;
	}
}
